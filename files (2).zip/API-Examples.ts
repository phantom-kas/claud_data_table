// Example Backend API Implementations
// These examples show how your backend should structure responses

// ============================================================================
// Example 1: Express.js (Node.js)
// ============================================================================

import express from 'express'
import { Request, Response } from 'express'

const app = express()

// Simple format endpoint
app.get('/api/payments', async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1
  const limit = parseInt(req.query.limit as string) || 20
  const search = req.query.search as string || ''

  // Fetch from database (example with Prisma)
  const skip = (page - 1) * limit
  
  const payments = await db.payment.findMany({
    where: search ? {
      OR: [
        { email: { contains: search, mode: 'insensitive' } },
        { id: { contains: search, mode: 'insensitive' } },
      ],
    } : {},
    skip,
    take: limit + 1, // Fetch one extra to check if there's a next page
    orderBy: { createdAt: 'desc' },
  })

  const hasMore = payments.length > limit
  const data = hasMore ? payments.slice(0, limit) : payments

  res.json({
    data,
    nextPage: hasMore ? page + 1 : undefined,
  })
})

// ============================================================================
// Example 2: Next.js API Route
// ============================================================================

// app/api/users/route.ts
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const page = parseInt(searchParams.get('page') || '1')
  const limit = parseInt(searchParams.get('limit') || '20')
  const q = searchParams.get('q') || ''

  try {
    const skip = (page - 1) * limit

    // Example with database query
    const [users, total] = await Promise.all([
      db.user.findMany({
        where: q ? {
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { email: { contains: q, mode: 'insensitive' } },
            { username: { contains: q, mode: 'insensitive' } },
          ],
        } : {},
        skip,
        take: limit,
        select: {
          id: true,
          name: true,
          username: true,
          email: true,
          role: true,
          avatar: true,
        },
      }),
      db.user.count({
        where: q ? {
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { email: { contains: q, mode: 'insensitive' } },
            { username: { contains: q, mode: 'insensitive' } },
          ],
        } : {},
      }),
    ])

    const hasMore = skip + limit < total

    return NextResponse.json({
      data: users,
      nextPage: hasMore ? page + 1 : undefined,
      total,
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch users' },
      { status: 500 }
    )
  }
}

// ============================================================================
// Example 3: Django (Python)
// ============================================================================

"""
# views.py
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from django.db.models import Q
from .models import Product
from .serializers import ProductSerializer

@api_view(['GET'])
def get_products(request):
    page = int(request.GET.get('page', 1))
    limit = int(request.GET.get('limit', 20))
    search = request.GET.get('search', '')
    
    # Build query
    queryset = Product.objects.all()
    
    if search:
        queryset = queryset.filter(
            Q(name__icontains=search) | 
            Q(category__icontains=search)
        )
    
    # Paginate
    start = (page - 1) * limit
    end = start + limit + 1  # Get one extra
    
    products = list(queryset[start:end])
    has_more = len(products) > limit
    
    if has_more:
        products = products[:limit]
    
    serializer = ProductSerializer(products, many=True)
    
    return Response({
        'data': serializer.data,
        'nextPage': page + 1 if has_more else None
    })
"""

// ============================================================================
// Example 4: Laravel (PHP)
// ============================================================================

"""
// routes/api.php
Route::get('/payments', [PaymentController::class, 'index']);

// PaymentController.php
public function index(Request $request)
{
    $page = $request->input('page', 1);
    $limit = $request->input('limit', 20);
    $search = $request->input('search', '');

    $query = Payment::query();

    if ($search) {
        $query->where(function($q) use ($search) {
            $q->where('email', 'like', "%{$search}%")
              ->orWhere('id', 'like', "%{$search}%");
        });
    }

    $skip = ($page - 1) * $limit;
    
    // Get one extra to check if there's more
    $payments = $query->skip($skip)
                     ->take($limit + 1)
                     ->get();

    $hasMore = $payments->count() > $limit;
    
    if ($hasMore) {
        $payments = $payments->take($limit);
    }

    return response()->json([
        'data' => $payments,
        'nextPage' => $hasMore ? $page + 1 : null,
    ]);
}
"""

// ============================================================================
// Example 5: FastAPI (Python)
// ============================================================================

"""
from fastapi import FastAPI, Query
from typing import Optional, List
from pydantic import BaseModel

app = FastAPI()

class Payment(BaseModel):
    id: str
    amount: float
    status: str
    email: str

class PaginatedResponse(BaseModel):
    data: List[Payment]
    nextPage: Optional[int]

@app.get("/api/payments", response_model=PaginatedResponse)
async def get_payments(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None
):
    skip = (page - 1) * limit
    
    # Database query example
    query = db.query(PaymentModel)
    
    if search:
        query = query.filter(
            (PaymentModel.email.contains(search)) |
            (PaymentModel.id.contains(search))
        )
    
    payments = query.offset(skip).limit(limit + 1).all()
    
    has_more = len(payments) > limit
    data = payments[:limit] if has_more else payments
    
    return {
        "data": data,
        "nextPage": page + 1 if has_more else None
    }
"""

// ============================================================================
// Example 6: Supabase
// ============================================================================

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

async function getPayments(page: number, limit: number, search: string) {
  const start = (page - 1) * limit
  const end = start + limit - 1

  let query = supabase
    .from('payments')
    .select('*', { count: 'exact' })
    .range(start, end)
    .order('created_at', { ascending: false })

  if (search) {
    query = query.or(`email.ilike.%${search}%,id.ilike.%${search}%`)
  }

  const { data, error, count } = await query

  if (error) throw error

  const hasMore = count ? start + limit < count : false

  return {
    data,
    nextPage: hasMore ? page + 1 : undefined,
    total: count,
  }
}

// ============================================================================
// Example 7: Firebase/Firestore
// ============================================================================

import { collection, query, where, orderBy, limit as fbLimit, startAfter, getDocs } from 'firebase/firestore'

async function getProducts(page: number, limit: number, search: string, lastDoc?: any) {
  const productsRef = collection(db, 'products')
  
  let q = query(
    productsRef,
    orderBy('createdAt', 'desc'),
    fbLimit(limit + 1) // Get one extra
  )

  if (search) {
    q = query(q, where('name', '>=', search), where('name', '<=', search + '\uf8ff'))
  }

  if (lastDoc) {
    q = query(q, startAfter(lastDoc))
  }

  const snapshot = await getDocs(q)
  const products = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
  
  const hasMore = products.length > limit
  const data = hasMore ? products.slice(0, limit) : products
  const lastVisible = snapshot.docs[snapshot.docs.length - 2] // Second to last

  return {
    data,
    nextPage: hasMore ? page + 1 : undefined,
    lastDoc: hasMore ? lastVisible : null,
  }
}

// ============================================================================
// Example 8: MongoDB with Mongoose
// ============================================================================

import mongoose from 'mongoose'

async function getUsers(page: number, limit: number, search: string) {
  const skip = (page - 1) * limit

  const filter = search
    ? {
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
          { username: { $regex: search, $options: 'i' } },
        ],
      }
    : {}

  const users = await User.find(filter)
    .skip(skip)
    .limit(limit + 1)
    .sort({ createdAt: -1 })
    .select('id name username email role avatar')
    .lean()

  const hasMore = users.length > limit
  const data = hasMore ? users.slice(0, limit) : users

  return {
    data,
    nextPage: hasMore ? page + 1 : undefined,
  }
}

// ============================================================================
// Key Patterns for All Backends:
// ============================================================================

/*
1. PAGINATION:
   - Get page and limit from query params
   - Calculate skip/offset: (page - 1) * limit
   - Fetch limit + 1 items to check if there's more
   - Return only 'limit' items in response

2. SEARCH:
   - Get search term from query params
   - Use case-insensitive search
   - Search across multiple fields with OR
   - Only apply search if term is provided

3. RESPONSE FORMAT:
   {
     data: [...],           // Array of items
     nextPage: 2,           // Next page number or null/undefined
     total?: 100            // Optional: total count
   }

4. PERFORMANCE:
   - Add database indexes on searchable fields
   - Use pagination to limit query size
   - Consider caching for frequently accessed data
   - Use database-level filtering, not application-level

5. ERROR HANDLING:
   - Return appropriate HTTP status codes
   - Include error messages in response
   - Log errors for debugging
   - Handle edge cases (invalid page, limit)
*/

export {}
